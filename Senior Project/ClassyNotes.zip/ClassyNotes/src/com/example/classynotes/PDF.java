package com.example.classynotes;

import android.graphics.Bitmap;
import android.os.Parcel;
import android.os.Parcelable;

public class PDF //implements Parcelable{
{
	private Bitmap bmp;
	
	PDF(Bitmap b)
	{
		bmp = b;
	}
	
	public Bitmap getBmp()
	{
		return bmp;
	}

//	@Override
//	public int describeContents() {
//		// TODO Auto-generated method stub
//		return 0;
//	}
//
//	@Override
//	public void writeToParcel(Parcel arg0, int arg1) {
//		// TODO Auto-generated method stub
//		
//	}
//	public static final Parcelable.Creator<DrawingInfo> CREATOR
//    = new Parcelable.Creator<DrawingInfo>() {
//public DrawingInfo createFromParcel(Parcel in) {
//    return new DrawingInfo(in);
//}
//
//public MyParcelable[] newArray(int size) {
//    return new MyParcelable[size];
//}
//};

}
